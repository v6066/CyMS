﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cyMs.基本信息
{
    public partial class FrmDesk : Form
    {
        public FrmDesk()
        {
            InitializeComponent();
        }

        private void FrmDesk_Load(object sender, EventArgs e)
        {
            //查询桌台信息，显示到窗体
            SqlConnection mycon = new SqlConnection("Data Source=VAPTS;Initial Catalog=db-mrcy;Integrated Security=True");
            string sql = "select TableID as 桌台号,TablePosition as 桌台位置,TableStatue as 状态,Remark as 标记 from tb_table";
            //SqlCommand mycom = new SqlCommand(sql, mycon);
            //数据存储中间体为内存，用SqlCommand数据库必须在线
            //而用SqlDataAdapter可以直接从内存中读取
            //而不用依赖于数据库是否在线
            SqlDataAdapter myadapter = new SqlDataAdapter(sql,mycon);
            //在内存中定义一个DataSet对象，在内存中访问数据并存放查询结果,相当于数学中的集合
            DataSet myset = new DataSet();
            //执行存放结果
            myadapter.Fill(myset, "tb_table");
            //放在窗体中显示查询到的结果
            this.dataGridView1.DataSource=myset.Tables["tb_table"];
        }
    }
}

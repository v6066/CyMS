﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cyMs.登录模块
{
        public partial class FrmRegister : Form
        {
            Random myrd = new Random();
            public FrmRegister()
            {
                InitializeComponent();
            }
            private void FrmRegister_Load(object sender, EventArgs e)
            {
                this.lb_yzm.Text += myrd.Next(0, 10).ToString();
                this.lb_yzm.Text += (Convert.ToChar(myrd.Next(97, 123))).ToString();

                this.lb_yzm.Text += myrd.Next(0, 10).ToString();
                this.lb_yzm.Text += (Convert.ToChar(myrd.Next(65, 91))).ToString();
            }

        private void lb_yzm_Click_1(object sender, EventArgs e)
        {
            this.lb_yzm.Text += myrd.Next(0, 10).ToString();
            this.lb_yzm.Text = (Convert.ToChar(myrd.Next(97, 123))).ToString();

            this.lb_yzm.Text += myrd.Next(0, 10).ToString();
            this.lb_yzm.Text = (Convert.ToChar(myrd.Next(65, 91))).ToString();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.tx_regUPwd.Text = this.tx_regUName.Text = this.tx_qrm.Text = "";
            this.tx_yzm.Text = "";
            this.tx_yzm.Focus();
            lb_yzm_Click_1(null, null);
            return;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (this.tx_regUName.Text.Trim() == "")
            {
                MessageBox.Show("用户名不能为空！");
                this.tx_regUName.Text = "";
                this.tx_regUName.Focus();
                return;
            }
            if (this.tx_yzm.Text.ToUpper() != this.lb_yzm.Text.ToUpper())
            {
                MessageBox.Show("验证码输入有误！");
                this.tx_yzm.Text = "";
                this.tx_yzm.Focus();
                lb_yzm_Click_1(null, null);
                return;
            }
            SqlConnection mycon = new SqlConnection("Data Source=VAPTS;Initial Catalog=db-mrcy;Integrated Security=True");
            int level = 2;
            if (this.radioButton1.Checked == true)
                level = 0;
            if (this.radioButton2.Checked == true)
                level = 1;

            string sql = "insert into tb_User values('" + this.tx_regUName.Text + "','" + this.tx_regUPwd.Text + "'," + level + ")";
            SqlCommand mycom = new SqlCommand(sql, mycon);
            mycon.Open();
            int n = mycom.ExecuteNonQuery();
            mycon.Close();

            if (n > 0)
            { MessageBox.Show("注册成功！"); }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            //
        }
    }
    }


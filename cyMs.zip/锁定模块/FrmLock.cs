﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cyMs
{
    
    public partial class FrmLock : Form
    {
        public static bool FrmClose = false;
        public FrmLock()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.tx_jsm.Text.Trim()==FrmMain.uPwd.Trim())
            {
            FrmClose = true;
            //解锁成功
            this.Close();
            }
            else { MessageBox.Show("解锁码输入有误！");
                this.tx_jsm.Text = "";
                this.tx_jsm.Focus();
            }
        }

        private void FrmLock_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (FrmClose == false)
            {
                MessageBox.Show("没给开发者打钱还想解锁！");
                this.tx_jsm.Text = "";
                this.tx_jsm.Focus();
                e.Cancel = true;
            }
        }
    }
}

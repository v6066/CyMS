﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cyMs
{
    public partial class Frm_Passward : Form
    {
        public Frm_Passward()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //1.非空验证
            if (this.tx_ymm.Text.Trim() == "")
            {
                MessageBox.Show("原密码不能为空！");
                this.tx_ymm.Text = "";
                this.tx_ymm.Focus();
                return;
            }
            if (this.tx_xgmm.Text.Trim() == "")
            {
                MessageBox.Show("修改密码不能为空！");
                this.tx_xgmm.Text = "";
                this.tx_xgmm.Focus();
                return;
            }
            if (this.tx_qrmm.Text.Trim() == "")
            {
                MessageBox.Show("确认码不能为空！");
                this.tx_qrmm.Text = "";
                this.tx_qrmm.Focus();
                return;
            }
            //3.原密码验证
            if (this.tx_ymm.Text != FrmMain.uPwd)
            {
                MessageBox.Show("原密码不一致！");
                this.tx_ymm.Text = "";
                this.tx_ymm.Focus();
                return;
            }

            //3.密码验证
            if (this.tx_qrmm.Text != this.tx_xgmm.Text)
            {
                MessageBox.Show("密码不一致！");
                this.tx_xgmm.Text = "";
                this.tx_qrmm.Text = "";
                this.tx_xgmm.Focus();
                return;
            }
            try
            {
                string sql = "update tb_user set [uPwd]='" + this.tx_qrmm.Text + "' where [id]='" + FrmMain.uId + "'";
                SqlConnection mycon = new SqlConnection("Data Source=VAPTS;Initial Catalog=db-mrcy;Integrated Security=True");
                SqlCommand mycom = new SqlCommand(sql, mycon);
                mycon.Open();
                int n = mycom.ExecuteNonQuery();
                mycon.Close();
                if (n > 0)
                {
                    MessageBox.Show("修改成功！");
                    Application.Restart();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Frm_Passward_Load(object sender, EventArgs e)
        {
            this.lb_name.Text = FrmMain.uName;
            int level = FrmMain.level;
            switch (level)
            {
                case 0:
                    this.lb_level.Text = "超级用户";
                    break;
                case 1:
                    this.lb_level.Text = "经理";
                    break;
                case 2:
                    this.lb_level.Text = "普通用户";
                    break;
            }
        }
    }
}

﻿using cyMs.登录模块;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cyMs
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //login  -->>database
            //登录：查询tb_user表是否存在输入的账号信息
            //1 数据库访问：链接到服务器-> .net  Connection
            //指定连接字符串：服务器名，数据库名，登录方式
            //SqlConnection mycon = new SqlConnection("Data Source=.;Initial Catalog=dbCyms;Integrated Security=True");
            SqlConnection mycon = new SqlConnection("Data Source=VAPTS;Initial Catalog=db-mrcy;Integrated Security=True");

            //2.定义一个command对象，指定SQL语句及连接对象
            //string sql = "select * from tb_user where uName='kwg' and uPwd='123'";
            string sql = "select * from tb_user where uName='" + this.cb_uName.Text + "' and uPwd='" + this.tx_uPwd.Text + "'";
            SqlCommand mycom = new SqlCommand(sql, mycon);

            //3.打开连接
            mycon.Open();

            //4.执行SQL语句,存放查询结果SqlDataReader类型
            SqlDataReader myrd = mycom.ExecuteReader();

            //判断是否读取到数据
            if (myrd.Read() == true)
            {
                //成功
                //传值给主窗体
                FrmMain.isLoginOk = true;

                FrmMain.uId = Convert.ToInt32(myrd["id"]);
                //FrmMain.uName = this.cb_uName.Text;
                FrmMain.uName = myrd["uName"].ToString();
                //FrmMain.uPwd = this.tx_uPwd.Text;
                FrmMain.uPwd = myrd["uPwd"].ToString();
                FrmMain.level = Convert.ToInt32(myrd["level"]);

                //5.关闭连接
                mycon.Close();
                //关登录窗体
                this.Close();
            }
            else
            {
                //失败
                MessageBox.Show("用户名或密码输入有误！");
                this.tx_uPwd.Text = "";
                this.tx_uPwd.Focus();
                //5.关闭连接
                mycon.Close();
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void tx_uPwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void cb_uName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmRegister myform = new FrmRegister();
            myform.ShowDialog();
        }
    }
}

﻿namespace cyMs
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.基本信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.桌台信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.职员信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.食品信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.辅助工具ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.日历ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.记事本ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.计算器ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统维护ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.权限管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统备份ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统恢复ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.口令设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.锁定系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.注册新用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于我们ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.切换账号ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslb_uName = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslb_level = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslb_systemTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.基本信息管理ToolStripMenuItem,
            this.辅助工具ToolStripMenuItem,
            this.系统维护ToolStripMenuItem,
            this.系统设置ToolStripMenuItem,
            this.帮助ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(956, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 基本信息管理ToolStripMenuItem
            // 
            this.基本信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.桌台信息管理ToolStripMenuItem,
            this.职员信息管理ToolStripMenuItem,
            this.食品信息管理ToolStripMenuItem});
            this.基本信息管理ToolStripMenuItem.Name = "基本信息管理ToolStripMenuItem";
            this.基本信息管理ToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.基本信息管理ToolStripMenuItem.Text = "基本信息管理";
            // 
            // 桌台信息管理ToolStripMenuItem
            // 
            this.桌台信息管理ToolStripMenuItem.Name = "桌台信息管理ToolStripMenuItem";
            this.桌台信息管理ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.桌台信息管理ToolStripMenuItem.Text = "桌台信息管理";
            this.桌台信息管理ToolStripMenuItem.Click += new System.EventHandler(this.桌台信息管理ToolStripMenuItem_Click);
            // 
            // 职员信息管理ToolStripMenuItem
            // 
            this.职员信息管理ToolStripMenuItem.Name = "职员信息管理ToolStripMenuItem";
            this.职员信息管理ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.职员信息管理ToolStripMenuItem.Text = "职员信息管理";
            // 
            // 食品信息管理ToolStripMenuItem
            // 
            this.食品信息管理ToolStripMenuItem.Name = "食品信息管理ToolStripMenuItem";
            this.食品信息管理ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.食品信息管理ToolStripMenuItem.Text = "食品信息管理";
            // 
            // 辅助工具ToolStripMenuItem
            // 
            this.辅助工具ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.日历ToolStripMenuItem,
            this.记事本ToolStripMenuItem,
            this.计算器ToolStripMenuItem});
            this.辅助工具ToolStripMenuItem.Name = "辅助工具ToolStripMenuItem";
            this.辅助工具ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.辅助工具ToolStripMenuItem.Text = "辅助工具";
            // 
            // 日历ToolStripMenuItem
            // 
            this.日历ToolStripMenuItem.Name = "日历ToolStripMenuItem";
            this.日历ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.日历ToolStripMenuItem.Text = "日历";
            // 
            // 记事本ToolStripMenuItem
            // 
            this.记事本ToolStripMenuItem.Name = "记事本ToolStripMenuItem";
            this.记事本ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.记事本ToolStripMenuItem.Text = "记事本";
            this.记事本ToolStripMenuItem.Click += new System.EventHandler(this.记事本ToolStripMenuItem_Click);
            // 
            // 计算器ToolStripMenuItem
            // 
            this.计算器ToolStripMenuItem.Name = "计算器ToolStripMenuItem";
            this.计算器ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.计算器ToolStripMenuItem.Text = "计算器";
            this.计算器ToolStripMenuItem.Click += new System.EventHandler(this.计算器ToolStripMenuItem_Click);
            // 
            // 系统维护ToolStripMenuItem
            // 
            this.系统维护ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.权限管理ToolStripMenuItem,
            this.系统备份ToolStripMenuItem,
            this.系统恢复ToolStripMenuItem});
            this.系统维护ToolStripMenuItem.Name = "系统维护ToolStripMenuItem";
            this.系统维护ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.系统维护ToolStripMenuItem.Text = "系统维护";
            // 
            // 权限管理ToolStripMenuItem
            // 
            this.权限管理ToolStripMenuItem.Name = "权限管理ToolStripMenuItem";
            this.权限管理ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.权限管理ToolStripMenuItem.Text = "权限管理";
            // 
            // 系统备份ToolStripMenuItem
            // 
            this.系统备份ToolStripMenuItem.Name = "系统备份ToolStripMenuItem";
            this.系统备份ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.系统备份ToolStripMenuItem.Text = "系统备份";
            // 
            // 系统恢复ToolStripMenuItem
            // 
            this.系统恢复ToolStripMenuItem.Name = "系统恢复ToolStripMenuItem";
            this.系统恢复ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.系统恢复ToolStripMenuItem.Text = "系统恢复";
            // 
            // 系统设置ToolStripMenuItem
            // 
            this.系统设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.口令设置ToolStripMenuItem,
            this.锁定系统ToolStripMenuItem,
            this.注册新用户ToolStripMenuItem});
            this.系统设置ToolStripMenuItem.Name = "系统设置ToolStripMenuItem";
            this.系统设置ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.系统设置ToolStripMenuItem.Text = "系统设置";
            // 
            // 口令设置ToolStripMenuItem
            // 
            this.口令设置ToolStripMenuItem.Name = "口令设置ToolStripMenuItem";
            this.口令设置ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.口令设置ToolStripMenuItem.Text = "口令设置";
            this.口令设置ToolStripMenuItem.Click += new System.EventHandler(this.口令设置ToolStripMenuItem_Click);
            // 
            // 锁定系统ToolStripMenuItem
            // 
            this.锁定系统ToolStripMenuItem.Name = "锁定系统ToolStripMenuItem";
            this.锁定系统ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.锁定系统ToolStripMenuItem.Text = "锁定系统";
            this.锁定系统ToolStripMenuItem.Click += new System.EventHandler(this.锁定系统ToolStripMenuItem_Click);
            // 
            // 注册新用户ToolStripMenuItem
            // 
            this.注册新用户ToolStripMenuItem.Name = "注册新用户ToolStripMenuItem";
            this.注册新用户ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.注册新用户ToolStripMenuItem.Text = "注册新用户";
            this.注册新用户ToolStripMenuItem.Click += new System.EventHandler(this.注册新用户ToolStripMenuItem_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于我们ToolStripMenuItem});
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.帮助ToolStripMenuItem.Text = "帮助";
            // 
            // 关于我们ToolStripMenuItem
            // 
            this.关于我们ToolStripMenuItem.Name = "关于我们ToolStripMenuItem";
            this.关于我们ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.关于我们ToolStripMenuItem.Text = "关于我们";
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.切换账号ToolStripMenuItem,
            this.退出系统ToolStripMenuItem});
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.退出ToolStripMenuItem.Text = "退出";
            // 
            // 切换账号ToolStripMenuItem
            // 
            this.切换账号ToolStripMenuItem.Name = "切换账号ToolStripMenuItem";
            this.切换账号ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.切换账号ToolStripMenuItem.Text = "切换账号";
            this.切换账号ToolStripMenuItem.Click += new System.EventHandler(this.切换账号ToolStripMenuItem_Click);
            // 
            // 退出系统ToolStripMenuItem
            // 
            this.退出系统ToolStripMenuItem.Name = "退出系统ToolStripMenuItem";
            this.退出系统ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.退出系统ToolStripMenuItem.Text = "退出系统";
            this.退出系统ToolStripMenuItem.Click += new System.EventHandler(this.退出系统ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.tslb_uName,
            this.toolStripStatusLabel3,
            this.tslb_level,
            this.toolStripStatusLabel5,
            this.tslb_systemTime});
            this.statusStrip1.Location = new System.Drawing.Point(0, 618);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(956, 26);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(69, 20);
            this.toolStripStatusLabel1.Text = "用户名：";
            // 
            // tslb_uName
            // 
            this.tslb_uName.Name = "tslb_uName";
            this.tslb_uName.Size = new System.Drawing.Size(84, 20);
            this.tslb_uName.Text = "显示用户名";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(84, 20);
            this.toolStripStatusLabel3.Text = "用户权限：";
            // 
            // tslb_level
            // 
            this.tslb_level.Name = "tslb_level";
            this.tslb_level.Size = new System.Drawing.Size(99, 20);
            this.tslb_level.Text = "显示用户权限";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(84, 20);
            this.toolStripStatusLabel5.Text = "系统时间：";
            // 
            // tslb_systemTime
            // 
            this.tslb_systemTime.Name = "tslb_systemTime";
            this.tslb_systemTime.Size = new System.Drawing.Size(99, 20);
            this.tslb_systemTime.Text = "显示系统时间";
            // 
            // statusStrip2
            // 
            this.statusStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip2.Location = new System.Drawing.Point(0, 596);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip2.Size = new System.Drawing.Size(956, 22);
            this.statusStrip2.TabIndex = 3;
            this.statusStrip2.Text = "statusStrip2";
            this.statusStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip2_ItemClicked);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 644);
            this.Controls.Add(this.statusStrip2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmMain";
            this.Text = "         ";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 基本信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 桌台信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 职员信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 食品信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 辅助工具ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 日历ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 记事本ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 计算器ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统维护ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 权限管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统备份ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统恢复ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 口令设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 锁定系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 注册新用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于我们ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 切换账号ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统ToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel tslb_uName;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel tslb_level;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel tslb_systemTime;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.Timer timer1;

    }
}


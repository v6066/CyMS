﻿using cyMs.基本信息;
using cyMs.登录模块;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cyMs
{
    public partial class FrmMain : Form
    {
       //1
        public static bool isLoginOk = false;  //记录登录状态
        public static int uId, level;  //记录用户编号，等级
        public static string uName, uPwd;  //记录用户名，密码

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            FrmLogin myform = new FrmLogin();
            myform.ShowDialog();

            //3
            if(isLoginOk==false)
            {
                this.Close();
            }
            else
            {
                //显示用户信息及启动系统时钟
                this.timer1.Enabled = true;
                //显示用户信息(用户名，用户权限)
                this.tslb_uName.Text=uName;
               // this.tslb_level.Text = level.ToString();
                switch (level)
                {
                    case 0:
                        this.tslb_level.Text = "超级用户";
                        break;
                    case 1:
                        this.tslb_level.Text = "经理";
                        break;
                    case 2:
                        this.tslb_level.Text = "普通用户";
                        break;
                }

            }
          



        }

        private void 退出系统ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("您确定要退出吗？","消息提示",MessageBoxButtons.YesNo,MessageBoxIcon.Information)==DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void 切换账号ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("您确定切换吗？", "消息提示", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                Application.Restart();
            }
        }

        private void 记事本ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("notepad.exe");
        }

        private void 计算器ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("calc.exe");
        }

        private void 注册新用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRegister myform = new FrmRegister();
            myform.ShowDialog();
        }

        private void 口令设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //密码修改
            Frm_Passward myform = new Frm_Passward();
            myform.ShowDialog();
        }

        private void 锁定系统ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmLock myform = new FrmLock();
            myform.ShowDialog();
        }

        private void 桌台信息管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmDesk myform = new FrmDesk();
            myform.ShowDialog();
        }

        private void statusStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.tslb_systemTime.Text=DateTime.Now.ToString();
        }
    }
}
